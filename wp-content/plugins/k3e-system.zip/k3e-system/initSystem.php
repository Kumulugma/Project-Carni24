<?php

class initSystem {

    const PLUGIN_NAME = "K3e - System";
    const PLUGIN_SLUG = "k3e_system";
    const PLUGIN_BOOTSTRAP =  'k3e-system';
    const PLUGIN_DIR =  'k3e-system';
    const PLUGIN_URL =  ABSPATH . 'wp-content/plugins/'.PLUGIN_DIR.'/';
	
	public static function init()
	{
		add_filter('plugins_api', 'k3e_plugin_info', 20, 3);

		function k3e_plugin_info( $res, $action, $args ){
		 
			if( 'plugin_information' !== $action ) {
				return false;
			}
		 
			$plugin_slug = initPluginsAutoupdate::PLUGIN_SLUG; 

			if( $plugin_slug !== $args->slug ) {
				return false;
			}
		 
			// trying to get from cache first
			if( false == $remote = get_transient( 'k3e_update_' . $plugin_slug ) ) {
		 
				// info.json is the file with the actual plugin information on your server
				$remote = wp_remote_get( initPluginsAutoupdate::PLUGIN_INFO_JSON , array(
					'timeout' => 10,
					'headers' => array(
						'Accept' => 'application/json'
					) )
				);
		 
				if ( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {
					set_transient( 'k3e_update_' . $plugin_slug, $remote, 43200 ); // 12 hours cache
				}
		 
			}
		 
			if( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {
		 
				$remote = json_decode( $remote['body'] );
				$res = new stdClass();
		 
				$res->name = $remote->name;
				$res->slug = $plugin_slug;
				$res->version = $remote->version;
				$res->tested = $remote->tested;
				$res->requires = $remote->requires;
				$res->author = '<a href="https://k3e.pl">K3e.pl</a>';
				$res->author_profile = '';
				$res->download_link = $remote->download_url;
				$res->trunk = $remote->download_url;
				$res->requires_php = '5.3';
				$res->last_updated = $remote->last_updated;
				$res->sections = array(
					'description' => $remote->sections->description,
					'installation' => $remote->sections->installation,
					'changelog' => $remote->sections->changelog
					// you can add your custom sections (tabs) here
				);
		 
				// in case you want the screenshots tab, use the following HTML format for its content:
				// <ol><li><a href="IMG_URL" target="_blank"><img src="IMG_URL" alt="CAPTION" /></a><p>CAPTION</p></li></ol>
				if( !empty( $remote->sections->screenshots ) ) {
					$res->sections['screenshots'] = $remote->sections->screenshots;
				}
		 
				$res->banners = array(
					'low' => 'https://YOUR_WEBSITE/banner-772x250.jpg',
					'high' => 'https://YOUR_WEBSITE/banner-1544x500.jpg'
				);
				return $res;
		 
			}
		 
			return false;
		 
		}
	}
	
	public static function run()
	{
		add_filter('site_transient_update_plugins', 'k3e_push_update' );
 
		function k3e_push_update( $transient ){
		 
			if ( empty($transient->checked ) ) {
					return $transient;
				}
		 
			// trying to get from cache first, to disable cache comment 10,20,21,22,24
			if( false == $remote = get_transient( 'k3e_upgrade_'.initPluginsAutoupdate::PLUGIN_SLUG ) ) {
		 
				// info.json is the file with the actual plugin information on your server
				$remote = wp_remote_get( initPluginsAutoupdate::PLUGIN_INFO_JSON , array(
					'timeout' => 10,
					'headers' => array(
						'Accept' => 'application/json'
					) )
				);
		 
				if ( !is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && !empty( $remote['body'] ) ) {
					set_transient( 'k3e_upgrade_'.initPluginsAutoupdate::PLUGIN_SLUG, $remote, 43200 ); // 12 hours cache
				}
		 
			}
		 
			if( $remote ) {
		 
				$remote = json_decode( $remote['body'] );
		 
				// your installed plugin version should be on the line below! You can obtain it dynamically of course 
				if( $remote && version_compare( '1.0', $remote->version, '<' ) && version_compare($remote->requires, get_bloginfo('version'), '<' ) ) {
					$res = new stdClass();
					$res->slug = initPluginsAutoupdate::PLUGIN_SLUG;
					$res->plugin = initPluginsAutoupdate::PLUGIN_DIR.'/'.initPluginsAutoupdate::PLUGIN_BOOTSTRAP.'.php';
					$res->new_version = $remote->version;
					$res->tested = $remote->tested;
					$res->package = $remote->download_url;
						$transient->response[$res->plugin] = $res;
						//$transient->checked[$res->plugin] = $remote->version;
					}
		 
			}
				return $transient;
		}
	}
	
    }
