<?php
require_once 'plugin-update-checker/plugin-update-checker.php';
if (!defined('ABSPATH'))
    exit;

/**
 *
 */
class k3eSystem {

    public static function init() {
        
    }



}
